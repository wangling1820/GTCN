from read_data_utils import *
import itertools


src_file = [
            r'.\networkdata\D3\D3.txt',
            ]
train_rate = [0.60]
val_rate = [0.10]
test_rate = [0.30]
edge_life_window = [20]
no_diag = [20]

make_symmetric = [True]
edge_life = [False]

print(src_file)

for setting in itertools.product(src_file, train_rate, val_rate, test_rate, edge_life, edge_life_window, no_diag, make_symmetric):
    read_data(src_file=setting[0],
              train_rate=setting[1],
              val_rate=setting[2],
              test_rate=setting[3],
              edge_life=setting[4],
              edge_life_window=setting[5],
              no_diag=setting[6],
              make_symmetric=setting[7])
print('Done!')
