from help import DataLoder, train, get_logging
from GTCN import *
import time

data_list = {
    'alpha': r'.\alpha\alpha_data_map_20_sym_7_1_2.mat',
}

name_list = ['alpha', 'otc']
model_list_run = [1]

for name in name_list:
    data_name = name
    model = m
    setting = {
        'lr': 0.1,
        'l2': 0,
        'len_m': 20,
        'R': 2,
        'emb_size': 20,
        'conv_size': 20,
        'loss': 'huber',
        'optim': 'Adam',
        'norm': True,
        'emb_tnn': False,
        'emb_type': 'R',
    }

    fname = data_list[data_name]
    dt = time.strftime("%m%d%H%M%S", time.localtime())
    logname = model + '_' + dt + \
              '_' + str(setting['lr']) + \
              '_' + str(setting['len_m']) + \
              '_' + str(setting['emb_size']) + \
              '_' + str(setting['conv_size']) + \
              '_' + str(setting['loss']) + \
              '_' + str(setting['optim']) + \
              '.log'
    log_dir = './'+ paper+ '/logging/' + data_name + '/' + logname
    print(data_name)
    logger = get_logging(log_dir)
    logger.info('data name is:' + fname)
    logger.info(logname)
    print()
    A, X, edges, target = DataLoder(fname, logger)
    gtcn = GTCN(X['train'], edges['train'], hidden_feat=[setting['emb_size'], setting['conv_size']])
    # train
    train(gtcn, A, X, edges, target, logger, setting)
    print('train done!')
