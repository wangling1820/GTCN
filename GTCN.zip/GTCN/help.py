import math
import logging
import torch
import torch.nn as nn
import torch as t
import numpy as np
import matrix_completion_model as ehf
import time
from read_data_utils import get_scale_data, get_X_features, func_laplacian_transformation, func_make_M, func_MProduct
from torch.optim.lr_scheduler import MultiStepLR
import scipy.io as sio


def get_logging(file_name):
    LOG_FORMAT = "%(asctime)s - %(levelname)s - %(message)s"
    DATE_FORMAT = "%Y-%m-%d %H:%M:%S"
    logging.basicConfig(filename=file_name, level=logging.DEBUG, format=LOG_FORMAT, datefmt=DATE_FORMAT)
    return logging


def get_sparse_tensor(saved_content, idx, vals, sz):
    st = t.sparse_coo_tensor(t.tensor(np.array(saved_content[idx], dtype=int), dtype=t.long),
                             t.squeeze(t.tensor(saved_content[vals], dtype=t.float64)), sz).coalesce()
    return st


def get_contend_info(Ct_x, T, C_sz, device='cpu'):
    Ct = []
    for j in range(T):
        idx = Ct_x._indices()[0] == j
        Ct.append(t.sparse_coo_tensor(Ct_x._indices()[1:3, idx], Ct_x._values()[idx], C_sz).to(device))
    return Ct



dir_list = ['./data/alpha/alpha_two_week_idx_M_len_20_sym_6_1_3.mat',
            './data/otc/otc_two_week_idx_M_len_20_sym_6_1_3.mat'
            ]

use_pos = False


def DataLoder(filename,logger, device='cpu'):
    saved_content = sio.loadmat(filename)
    # ============判断坐标上下界使用max - min + 1
    MT = np.min(saved_content["tensor_idx"][0])
    M1 = np.min(saved_content["tensor_idx"][1])
    M2 = np.min(saved_content["tensor_idx"][2])

    XT = np.max(saved_content["tensor_idx"][0])
    N1 = np.max(saved_content["tensor_idx"][1])
    N2 = np.max(saved_content["tensor_idx"][2])

    T = XT - MT + 1
    N = max(N1+1, N2 + 1)
    logger.info('len of time is %d, num of nodes is %d'%(T, N))
    sz = t.Size([T, N, N])
    C_sz = t.Size([N, N])

    A_train = get_sparse_tensor(saved_content, 'A_train_idx', 'A_train_vals', sz)
    A_val = get_sparse_tensor(saved_content, 'A_val_idx', 'A_val_vals', sz)
    A_test = get_sparse_tensor(saved_content, 'A_test_idx', 'A_test_vals', sz)

    Ct_train = get_sparse_tensor(saved_content, 'train_idx', 'train_vals', sz)
    Ct_val = get_sparse_tensor(saved_content, 'val_idx', 'val_vals', sz)
    Ct_test = get_sparse_tensor(saved_content, 'test_idx', 'test_vals', sz)

    train_label = get_sparse_tensor(saved_content, 'train_label_idx', 'train_label_vals', sz)
    val_label = get_sparse_tensor(saved_content, 'val_label_idx', 'val_label_vals', sz)
    test_label = get_sparse_tensor(saved_content, 'test_label_idx', 'test_label_vals', sz)

    A_train = A_train.to(device)
    A_val = A_val.to(device)
    A_test = A_test.to(device)

    train_label = train_label.to(device)
    val_label = val_label.to(device)
    test_label = test_label.to(device)

    Ct_train_2 = get_contend_info(Ct_train, T, C_sz)
    Ct_val_2 = get_contend_info(Ct_val, T, C_sz)
    Ct_test_2 = get_contend_info(Ct_test, T, C_sz)

    X_train = get_X_features(A_train)
    X_val = get_X_features(A_val)
    X_test = get_X_features(A_test)

    edges_train = train_label._indices().to(device)
    labels_train = train_label._values().to(device)

    edges_val = val_label._indices().to(device)
    labels_val = val_label._values().to(device)

    edges_test = test_label._indices().to(device)
    labels_test = test_label._values().to(device)

    target_train = torch.reshape(labels_train, (-1, 1)).to(device)
    target_val = torch.reshape(labels_val, (-1, 1)).to(device)
    target_test = torch.reshape(labels_test, (-1, 1)).to(device)
    logger.info('num of train is %d, num of val is %d, num of test is %d' %
                (target_train.shape[0], target_val.shape[0], target_test.shape[0]))
    target_train, target_val, target_test = get_scale_data(target_train, target_val, target_test)
    A = {
        'train': Ct_train_2,
        'val': Ct_val_2,
        'test': Ct_test_2
    }
    X = {
        'train': X_train,
        'val': X_val,
        'test': X_test,
    }
    edges = {
        'train': edges_train,
        'val': edges_val,
        'test': edges_test
    }
    target = {
        'train': target_train,
        'val': target_val,
        'test': target_test
    }

    return A, X, edges, target


def train(gcn, A, X, edges, target, logger, opt_setting, device='cpu'):
    train_time = 0

    gcn.to(device)
    total = sum([param.nelement() for param in gcn.parameters()])

    print("Number of parameters: %f" % (total))
    logger.info("Number of parameters: %f" % (total))

    if opt_setting['optim'] == 'Adam':
        optimizer = t.optim.Adam(gcn.parameters(), lr=opt_setting['lr'], weight_decay=opt_setting['l2'])
    elif opt_setting['optim'] == 'SGD':
        optimizer = t.optim.SGD(gcn.parameters(), lr=opt_setting['lr'], momentum=0.09, weight_decay=opt_setting['l2'])
    else:
        optimizer = None
        exit('未设置优化器！！')
    if opt_setting['loss'] == 'MAE':
        criterion = nn.L1Loss()
    elif opt_setting['loss'] == 'MSE':
        criterion = nn.MSELoss()
    elif opt_setting['loss'] == 'huber':
        criterion = nn.HuberLoss(reduction='sum', delta=1)
    else:
        criterion = None
        exit('未设置损失函数！')

    mae = nn.L1Loss()
    mse = nn.MSELoss()
    val_rmse_min = val_mae_min = 1e10
    rmse_break = mae_break = False
    ep = 1
    while ep <= 500:
        s_time = time.time()
        optimizer.zero_grad()
        output_train = gcn(A['train'], X['train'], edges['train'])
        loss_train = criterion(output_train, target['train'])
        loss_train.backward(retain_graph=True)
        optimizer.step()
        e_time = time.time()
        train_time += e_time - s_time
        continue_rmse = 1
        continue_mae = 1
        # 验证和测试
        with t.no_grad():
            rmse_train = math.sqrt(mse(output_train, target['train']))
            mae_train = mae(output_train, target['train'])

            # val
            output_val = gcn(A['val'], X['val'], edges['val'])
            rmse_val = math.sqrt(mse(output_val, target['val']))
            mae_val = mae(output_val, target['val'])

            # test
            output_test = gcn(A['test'], X['test'], edges['test'])
            rmse_test = math.sqrt(mse(output_test, target['test']))
            mae_test = mae(output_test, target['test'])

            logger.info("Ep %d. Train MAE  %.4f. Train RMSE %.4f." % (ep, mae_train, rmse_train))
            logger.info("Ep %d. Val MAE  %.4f. Val RMSE %.4f." % (ep, mae_val, rmse_val))
            logger.info("Ep %d. Test MAE  %.4f. Test RMSE %.4f.\n" % (ep, mae_test, rmse_test))

            print("Ep %d. Train MAE  %.4f. Train RMSE %.4f." % (ep, mae_train, rmse_train))
            print("Ep %d. Val MAE  %.4f. Val RMSE %.4f." % (ep, mae_val, rmse_val))
            print("Ep %d. Test MAE  %.4f. Test RMSE %.4f.\n" % (ep, mae_test, rmse_test))

            # early stopping setting
            if round(val_rmse_min, 4) >= round(rmse_val, 4):
                epoch_rmse = ep
                test_rmse_min = rmse_test
                val_rmse_min = rmse_val
            else:
                rmse_break = True

            if round(val_mae_min, 10) >= round(mae_val.item(), 10):
                epoch_mae = ep
                val_mae_min = mae_val.item()
                test_mae_min = mae_test
            else:
                mae_break = True

        if ep > 20 and rmse_val > 40 and mae_val > 40:
            logger.info('******this setting cant make model work!!*********')
            break
        ep += 1

        # scheduler.step()
    logger.info("Best MAE epoch is %d, Val MAE  %.4f." % (epoch_mae, test_mae_min))
    logger.info("Best RMSE epoch is %d, Test RMSE %.4f.\n" % (epoch_rmse, test_rmse_min))
    logger.info("Train Time is: %0.6f s" % (train_time))
    print("Best MAE epoch is %d, Val MAE  %.4f." % (epoch_mae, test_mae_min))
    print("Best RMSE epoch is %d, Test RMSE %.4f.\n" % (epoch_rmse, test_rmse_min))
    print("Train MAE  %.4f. Train RMSE %.4f." % (mae_train, rmse_train))
    print("Val MAE  %.4f. Val RMSE %.4f." % (mae_val, rmse_val))
    print("Test MAE  %.4f. Test RMSE %.4f.\n" % (mae_test, rmse_test))
    print("Train Time is: %0.6f s" % (train_time))

