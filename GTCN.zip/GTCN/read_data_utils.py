import numpy as np
import torch
from sklearn.utils import shuffle
import scipy.io as sio
import torch as t


def setup_seed(seed=3407):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)


def get_contend_info(Ct_x, T):
    Ct = []
    for j in range(T):
        idx = Ct_x._indices()[0] == j
        Ct.append(
            t.sparse_coo_tensor(Ct_x._indices()[1:3, idx], Ct_x._values()[idx], dtype=t.float64))
    return Ct


def get_X_features(A):

    X = t.zeros(A.shape[0], A.shape[1], 2, dtype=t.float64)

    X[:, :, 0] = t.sparse.sum(A, 1).to_dense()
    X[:, :, 1] = t.sparse.sum(A, 2).to_dense()
    return X


# TODO 增加节点的先验特征
def get_X_features_concate(A, use_pos=True):

    X = t.zeros(A.shape[0], A.shape[1], 2, dtype=t.float64)

    if use_pos:
        A_sin = t.sparse.sum(A, 1)  # T * N
        A_cos = t.sparse.sum(A, 2)  # T * N

        A_sin_T = A_sin._indices()[0]  # pos
        A_sin_pos = torch.sin(A_sin_T)
        A_sin_val = A_sin_pos + A_sin._values()
        A_sin_pe = torch.sparse_coo_tensor(A_sin._indices(), A_sin_val, A_sin.size())

        A_cos_T = A_cos._indices()[0]
        A_cos_val = torch.cos(A_cos_T) + A_cos._values()
        A_cos_pe = torch.sparse_coo_tensor(A_cos._indices(), A_cos_val, A_cos.size())

        X[:, :, 0] = A_sin_pe.coalesce().to_dense()
        X[:, :, 1] = A_cos_pe.coalesce().to_dense()
        # X[:, :, 2] =
    else:
        X[:, :, 0] = t.sparse.sum(A, 1).to_dense()
        X[:, :, 1] = t.sparse.sum(A, 2).to_dense()

    return X


def get_scale_data(train, val, test):

    min_train = min(train)
    min_val = min(val)
    min_test = min(test)

    max_train = max(train)
    max_val = max(val)
    max_test = max(test)

    min_res = min([min_train, min_val, min_test])
    max_res = max([max_train, max_val, max_test])
    print('数据最小值为：%f, 最大值为： %f.'%(min_res, max_res))
    scale_factor = max_res - min_res

    train_scale = (train - min_res)/ scale_factor
    val_scale = (val - min_res) / scale_factor
    test_scale = (test - min_res) / scale_factor


    return train_scale, val_scale, test_scale


def func_make_M(T, no_diag):
    M = np.zeros((T, T))  # R^T * T
    for i in range(no_diag):
        A = M[i:, :T - i]  # 取得M的i及以后所有行，T-i以前的所有列，目的是使得矩阵下三角成为1 使用A逐步替代减小的M
        np.fill_diagonal(A, 1)
    L = np.sum(M, axis=1)  # axis 表示取得矩阵哪个维度的和
    M = M / L[:, None]
    M = torch.tensor(M)
    return M


def get_random_idx(num_all, num_ones, random_state=3407):
    no_true = np.ones(num_ones) == 1
    no_false = np.zeros(num_all-num_ones) == 1
    temp = list(no_true) + list(no_false)
    idx = shuffle(torch.tensor(temp), random_state=random_state)
    return idx


def get_dataset(A, idx):
    sz = A.size()
    not_idx = idx == False

    index = torch.LongTensor(A._indices()[0:3, idx].size())  # 传入的是size
    index[0:3] = A._indices()[0:3, idx]
    values = A._values()[idx]
    sub = torch.sparse_coo_tensor(index, values, sz)

    remain_index = torch.LongTensor(A._indices()[0:3, not_idx].size())  # 传入的是size
    remain_index[0:3] = A._indices()[0:3, not_idx]
    remain_values = A._values()[not_idx]
    remain = torch.sparse_coo_tensor(remain_index, remain_values, sz)

    return remain.coalesce(), sub.coalesce()


def print_tensor(A, str):
    print('------------------------')
    print(str)
    print(A)
    print(torch.sum(A._values()))  # 稀疏矩阵
    print('------------------------')


# A的对称化
def func_make_symmetric(sparse_tensor, N, TT):
    count = 0
    tensor_idx = torch.LongTensor([])
    tensor_val = torch.FloatTensor([]).unsqueeze(1)
    A_idx = sparse_tensor._indices()
    A_val = sparse_tensor._values()
    for j in range(TT):
        idx = A_idx[0] == j  # 此时A_idx 的size-> 3*行数 t*n*n 去除t维度的所有坐标,每个时间片的A都要对称化
        mat = torch.sparse_coo_tensor(A_idx[1:3, idx], A_val[idx], torch.Size([N, N]))
        mat_t = mat.transpose(1, 0)
        sym_mat = mat + mat_t
        sym_mat = sym_mat / 2
        count = count + sym_mat._nnz()
        # vertices = torch.tensor(sym_mat._indices().detach())  # 对称A的位置坐标
        vertices = sym_mat._indices().clone().detach()  # 对称A的位置坐标
        time = torch.ones(sym_mat._nnz(), dtype=torch.long) * j  # 用来扩充 T 维度的数据,补充数据的时间T的标签
        time = time.unsqueeze(0)  # 由 N -> 1 * N 的数据格式
        full = torch.cat((time, vertices), 0)  # 在原有坐标上加上时序 t，构成 3*n 的坐标
        tensor_idx = torch.cat((tensor_idx, full), 1)  # 构建新的 sparse 矩阵的位置坐标 idx
        tensor_val = torch.cat((tensor_val, sym_mat._values().unsqueeze(1)), 0)  # 构建sparse矩阵的 val
    tensor_val.squeeze_(1)
    A = torch.sparse_coo_tensor(tensor_idx, tensor_val, torch.Size([TT, N, N])).coalesce()
    return A



# TODO A 中包含了所有时刻 T 中的每个邻接矩阵，所以需要按照时间片来处理 --> 将时间滑动窗口中的A_new更新，使得更稠密
def func_edge_life(A, N, TT, edge_life_window):
    A_new = A.clone()  # 使用 A 的坐标
    A_new._values()[:] = 0  # 所有设置为 0
    # idx = A._indices()[0] == 0  # 找到第一个坐标为 0 的列
    for t in range(TT):  # TODO why 0为时间维度下标,idx作用在行数,idx的size为3*T edge_life_window = 10
        idx = (A._indices()[0] >= max(0, t - edge_life_window + 1)) & (A._indices()[0] <= t)
        block = torch.sparse_coo_tensor(A._indices()[0:3, idx], A._values()[idx], torch.Size([TT, N, N]))
        block._indices()[0] = t
        A_new = A_new + block
    return A_new.coalesce()


# A hat = A*D^1/2
def func_laplacian_transformation(B, N, TT):
    vertices = torch.LongTensor([range(N), range(N)])
    tensor_idx = torch.LongTensor([])
    tensor_val = torch.DoubleTensor([]).unsqueeze(1)
    for j in range(TT):
        time = torch.ones(N, dtype=torch.long) * j
        time = time.unsqueeze(0)
        full = torch.cat((time, vertices), 0)
        tensor_idx = torch.cat((tensor_idx, full), 1)
        val = torch.ones(N, dtype=torch.float64)
        tensor_val = torch.cat((tensor_val, val.unsqueeze(1)), 0)
    tensor_val.squeeze_(1)
    I = torch.sparse_coo_tensor(tensor_idx, tensor_val, torch.Size([TT, N, N]))
    C = B + I
    tensor_idx = torch.LongTensor([])
    tensor_val = torch.DoubleTensor([]).unsqueeze(1)
    for j in range(TT):
        idx = C._indices()[0] == j
        mat = torch.sparse_coo_tensor(C._indices()[1:3, idx], C._values()[idx], torch.Size([N, N]))
        vec = torch.ones([N, 1], dtype=torch.float64)
        degree = 1 / torch.sqrt(torch.sparse.mm(mat, vec))
        index = torch.LongTensor(C._indices()[0:3, idx].size())
        values = torch.DoubleTensor(C._values()[idx].size())
        index[0] = j
        index[1:3] = mat._indices()
        values = mat._values()
        count = 0
        for i, j in index[1:3].transpose(1, 0):
            values[count] = values[count] * degree[i] * degree[j]
            count = count + 1
        tensor_idx = torch.cat((tensor_idx, index), 1)
        tensor_val = torch.cat((tensor_val, values.unsqueeze(1)), 0)
    tensor_val.squeeze_(1)
    C = torch.sparse_coo_tensor(tensor_idx, tensor_val, torch.Size([TT, N, N]))
    return C.coalesce()


# M size -> T*T
# TODO #####################################################
def func_MProduct(C, M, no_diag):
    assert C.size()[0] == M.size()[0]
    Tr = C.size()[0]  # T N N
    N = C.size()[1]  # N
    C_new = torch.sparse_coo_tensor(C.size())  # 用于记录结果
    for j in range(Tr):  # 遍历时间T
        idx = C._indices()[0] == j  # 找到每个片 idx 主要有三行，分别是 t n n
        # C._indices -> 3*行数,其中3 为 t n n
        # 找到时间片j的 n n matrix
        mat = torch.sparse_coo_tensor(C._indices()[1:3, idx], C._values()[idx], torch.Size([N, N]))
        tensor_idx = torch.zeros([3, mat._nnz()], dtype=torch.long)  # 存储idx
        tensor_idx[1:3] = mat._indices()[0:2]  # 存储 n n
        indices = torch.nonzero(M[:, j])  # TODO 是否应该取得i行的? 取得 j 列不为零的坐标
        assert indices.size()[0] <= no_diag  #
        # 遍历 indices
        for i in range(indices.size()[0]):
            tensor_idx[0] = indices[i]  # 处理idx
            tensor_val = M[indices[i], j] * mat._values()  # 处理val
            C_new = C_new + torch.sparse_coo_tensor(tensor_idx, tensor_val, C.size())
        C_new.coalesce()
    return C_new.coalesce()



def read_data(src_file, train_rate, val_rate, test_rate, edge_life, edge_life_window, no_diag, make_symmetric):

    setup_seed()
    print(src_file)
    data = np.loadtxt(src_file, delimiter=',', skiprows=1)
    save_file_location = src_file[:-4]
    file_name = '_M_len_' + str(no_diag)
    if edge_life:
        file_name = file_name + '_edge_' + str(edge_life_window)
    if make_symmetric:
        file_name = file_name + '_sym'
    save_file_name = file_name + '_' + str(train_rate)[-1] + '_' + str(val_rate)[-1] + '_' + str(test_rate)[-1] + '.mat'
    res_file = save_file_location + save_file_name
    data_len = data.shape[0]
    no_val_samples = int(data_len * val_rate)
    no_test_samples = int(data_len * test_rate)

    # data.size = N * N * V * T
    data = torch.tensor(data)  # tensor化数据
    # Create full tensor

    dates = np.unique(data[:, 3])  # 取出3+1列time的数据，然后使用unique去重，计算时间片数量 T ---> 64
    no_time_slices = len(dates)

    N = int(max(max(data[:, 0]), max(data[:, 1]))) + 1 # 需要保证起始点0,计算节点的个数，不如 Max-Min+1
    TT = int(no_time_slices)  # 时间片的大小
    M = func_make_M(TT, no_diag)


    # 稀疏矩阵的idx val size
    # 按照数据读取出来的,size of data = 行数 * 3 ==> tensor_idx的大小也是 = 行数 * 3，按照行*列的个数处理数据
    # 所以下面可以使用 == 判断某个时间t所在的位置
    tensor_idx = torch.zeros([data.size()[0], 3], dtype=torch.long)
    tensor_val = torch.ones([data.size()[0]], dtype=torch.float64)  # 构建邻接矩阵的时候使用
    tensor_labels = torch.zeros([data.size()[0]], dtype=torch.float64)

    for t in range(TT):
        idx = data[:, 3] == dates[t]  # 取得当前时刻坐标，设置为 True.
        # 转换成tensor,TODO,注意此处减去的 1, [0, 1, 2] --> Node, Node, value, time
        tensor_idx[idx, 1:3] = (data[idx, 0:2]).type('torch.LongTensor')  # 位置 起使为1
        tensor_idx[idx, 0] = t  # 此处 Time 片
        tensor_labels[idx] = data[idx, 2]  # value
    # tensor_id的size是 T*3,其中 3 包含了t*n*n.

    # 构建A ->  行数*3,其中 3 包含了t*n*n，一共数据行数 个 1 转置之后为 3 * 行数
        #  ===> 构建M ：
    A = torch.sparse_coo_tensor(tensor_idx.transpose(1, 0), tensor_val, torch.Size([TT, N, N])).coalesce()  # 邻接矩阵
    A_labels = torch.sparse_coo_tensor(tensor_idx.transpose(1, 0), tensor_labels,
                                         torch.Size([TT, N, N])).coalesce()  # 所有的值


    # TODO 分割数据

    val_idx_rand = get_random_idx(A_labels._nnz(), no_val_samples)
    test_idx_rand = get_random_idx(A_labels._nnz()-no_val_samples, no_test_samples)
    # train_idx_rand = test_idx_rand == False

    label_remain_data, label_val = get_dataset(A_labels, val_idx_rand)
    label_train, label_test = get_dataset(label_remain_data, test_idx_rand)

    A_test, A_val_temp = get_dataset(A, val_idx_rand)
    A_train, _ = get_dataset(A_test, test_idx_rand)

    A_val = torch.add(A_train, A_val_temp).coalesce()

    print('make_sym...')
    if make_symmetric:
        A_train_sym = func_make_symmetric(A_train, N, TT)
        A_test_sym = func_make_symmetric(A_test, N, TT)
        A_val_sym = func_make_symmetric(A_val, N, TT)
    else:
        A_train_sym = A_train
        A_test_sym = A_test
        A_val_sym = A_val

    print('edge_life...')
    if edge_life:
        A_train_sym_life = func_edge_life(A_train_sym, N, TT, edge_life_window)
        A_test_sym_life = func_edge_life(A_test_sym, N, TT, edge_life_window)
        A_val_sym_life = func_edge_life(A_val_sym, N, TT, edge_life_window)
    else:
        A_train_sym_life = A_train_sym
        A_test_sym_life = A_test_sym
        A_val_sym_life = A_val_sym

    print('func_laplacian_trans...')
    A_train_sym_life_la = func_laplacian_transformation(A_train_sym_life, N, TT)
    A_test_sym_life_la = func_laplacian_transformation(A_test_sym_life, N, TT)
    A_val_sym_life_la = func_laplacian_transformation(A_val_sym_life, N, TT)

    print('func_M_product...')
    # TODO remain_data 用于测试验证集合
    #  T 为训练数据的数量,TTT 为数据总量
    m_product = False
    if m_product:
        Ct_train = func_MProduct(A_train_sym_life_la, M, no_diag)  # There is a bug in matlab Bitcoin Alpha
        Ct_val = func_MProduct(A_val_sym_life_la, M, no_diag)  # 与M运算过的验证集 remain_data + val_data
        Ct_test = func_MProduct(A_test_sym_life_la, M, no_diag)  # 与M运算过的测试集
    else:
        Ct_train = A_train_sym_life_la
        Ct_val = A_val_sym_life_la
        Ct_test = A_test_sym_life_la

    print('store...')
    A_train_idx = A_train._indices()
    A_train_vals = A_train._values()

    A_val_idx = A_val.indices()
    A_val_vals = A_val._values()

    A_test_idx = A_test._indices()
    A_test_vals = A_test._values()

    val_label_idx = label_val._indices()
    val_label_vals = label_val._values()

    test_label_idx = label_test._indices()
    test_label_vals = label_test._values()

    train_label_idx = label_train._indices()
    train_label_vals = label_train._values()

    train_idx = Ct_train._indices()
    train_vals = Ct_train._values()

    val_idx = Ct_val._indices()
    val_vals = Ct_val._values()

    test_idx = Ct_test._indices()
    test_vals = Ct_test._values()

    sio.savemat(res_file, {
            'tensor_idx': np.array(tensor_idx.transpose(1, 0)),
            'tensor_labels': np.array(tensor_labels),

            'A_train_idx': np.array(A_train_idx),
            'A_train_vals': np.array(A_train_vals),

            'A_val_idx': np.array(A_val_idx),
            'A_val_vals': np.array(A_val_vals),

            'A_test_idx': np.array(A_test_idx),
            'A_test_vals': np.array(A_test_vals),

            'test_label_idx': np.array(test_label_idx),
            'test_label_vals': np.array(test_label_vals),

            'val_label_idx': np.array(val_label_idx),
            'val_label_vals': np.array(val_label_vals),

            'train_label_idx': np.array(train_label_idx),
            'train_label_vals': np.array(train_label_vals),

            'train_idx': np.array(train_idx),
            'train_vals': np.array(train_vals),

            'test_idx': np.array(test_idx),
            'test_vals': np.array(test_vals),

            'val_idx': np.array(val_idx),
            'val_vals': np.array(val_vals),

            'M': np.array(M)
        })
    print('数据保存于 %s .\n'%(res_file))
