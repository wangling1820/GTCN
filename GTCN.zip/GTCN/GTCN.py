import torch as t
import torch.nn as nn
import numpy as np

unsq = t.unsqueeze
sq = t.squeeze
import random


def setup_seed(seed=3407):
    t.manual_seed(seed)
    t.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    t.backends.cudnn.deterministic = True


class M_trans(nn.Module):
    def __init__(self, T, len_M, N=None):
        super(M_trans, self).__init__()
        setup_seed()
        self.len_M = len_M
        self.T = T
        self.N = N
        self.M = nn.Parameter(t.randn(T, T, dtype=t.float64))

    def forward(self, X):
        if type(X) == t.Tensor:
            T = X.shape[0]
            out = t.zeros(T, T, dtype=t.float64)
            for row in range(T):
                if row < self.len_M:
                    out[row, 0:row + 1] = t.softmax(self.M[row, 0:row + 1], dim=0)
                else:
                    out[row, row - self.len_M + 1:row + 1] = t.softmax(self.M[row, row - self.len_M + 1:row + 1], dim=0)
            output = t.matmul(out, X.reshape(self.T, -1))
            return output.reshape(X.shape)

        elif type(X) == list:
            T = len(X)
            sz = t.Size([self.N, self.N])
            res = []
            for tm in range(T):
                m = t.softmax(self.M[str(tm + 1)], dim=1)
                temp = t.sparse_coo_tensor(sz, dtype=t.float64)
                if tm < self.len_M:
                    for i in range(tm + 1):
                        A = X[i]
                        val = m[:, i] * A.values()
                        temp = temp + t.sparse_coo_tensor(A.indices(), val, sz)
                else:
                    for i in range(self.len_M):
                        A = X[tm - self.len_M + i]
                        val = m[:, i] * A.values()
                        temp = temp + t.sparse_coo_tensor(A.indices(), val, sz)
                res.append(temp.coalesce())
            return res
        else:
            exit('M_product is wrong!')


class GTCN(nn.Module):
    def __init__(self, At, X, edges, len_M, hidden_feat=[2, 4, 1], layers=1):
        super(GTCN, self).__init__()
        setup_seed()
        self.T = X.shape[0]
        self.N = X.shape[1]
        self.F = [X.shape[-1]] + hidden_feat
        self.M_product = M_trans(self.T, len_M, self.N)
        self.n_f = nn.Parameter(t.randn(N, F, dtype=t.float64), requires_grad=True)
        self.edges = edges
        self.layers = layers
        self.W_Conv_dic = nn.ParameterDict()
        self.W_Conv_dic['1'] = nn.Parameter(t.randn(self.F[1], self.F[2], dtype=t.float64))
        for l in range(2, layers + 1):
            self.W_Conv_dic[str(l)] = nn.Parameter(t.randn(self.F[2], self.F[2], dtype=t.float64))
        self.bias = nn.Parameter(t.randn(self.F[2], 1, dtype=t.float64))
        self.W_cat = nn.Parameter(t.randn(2 * self.F[2], self.F[2], dtype=t.float64))
        self.U = nn.Parameter(t.randn(self.F[2], 1, dtype=t.float64))
        self.sigmoid = nn.Sigmoid()
        self.relu = nn.ReLU()
        self.elu = nn.ELU()
        self.At = At
        self.v = t.tensor([self.N, 1], dtype=t.long)
        self.edge_src_nodes = t.matmul(edges[[0, 1]].transpose(1, 0), self.v)
        self.edge_trg_nodes = t.matmul(edges[[0, 2]].transpose(1, 0), self.v)

    def __call__(self, At=None, X=None, edges=None):
        return self.forward(At, X, edges)

    def compute_AtXt(self, A, X):
        Xt = self.M_product(X)
        At = self.M_product(A)
        Xt = t.reshape(Xt, (self.T, self.N, X.shape[-1]))
        AtXt = t.zeros(self.T, self.N, X.shape[-1], dtype=t.float64)
        for k in range(self.T):
            AtXt[k] = t.sparse.mm(At[k], Xt[k])
        return AtXt

    def forward(self, At=None, X=None, edges=None):
        self.n = self.n_f.repeat(self.T, 1, 1)
        Y = self.n
        if type(At) == list and type(X) == t.Tensor and type(edges) == t.Tensor:
            for l in range(1, self.layers + 1):
                AtXt = self.compute_AtXt(At, Y)
                if l == self.layers:
                    Y = self.sigmoid(t.matmul(AtXt, self.W_Conv_dic[str(l)]))
                else:
                    Y = self.sigmoid(t.matmul(AtXt, self.W_Conv_dic[str(l)]))
            edge_src_nodes = t.matmul(edges[[0, 1]].transpose(1, 0), self.v)
            edge_trg_nodes = t.matmul(edges[[0, 2]].transpose(1, 0), self.v)
        else:
            for l in range(1, self.layers + 1):
                AtXt = self.compute_AtXt(self.At, Y)
                if l == self.layers:
                    Y = self.sigmoid(t.matmul(AtXt, self.W_Conv_dic[str(l)]))
                else:
                    Y = self.sigmoid(t.matmul(AtXt, self.W_Conv_dic[str(l)]))
            edge_src_nodes = self.edge_src_nodes
            edge_trg_nodes = self.edge_trg_nodes
        src_nodes = Y.reshape(-1, self.F[2])[edge_src_nodes]
        trg_nodes = Y.reshape(-1, self.F[2])[edge_trg_nodes]
        rep_cat = t.matmul(t.cat((AXW_mat_edge_src_nodes, AXW_mat_edge_trg_nodes), dim=1), self.W_Conv_dic)
        rep_dot = src_nodes * trg_nodes
        rep_final = rep_dot + rep_cat + self.bias
        output = self.relu(t.matmul(rep_final, self.U))
        return output
